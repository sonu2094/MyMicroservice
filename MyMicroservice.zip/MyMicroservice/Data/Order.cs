﻿using System;
using System.Collections.Generic;

namespace MyMicroservice.Data;

public partial class Order
{
    public Guid OrderId { get; set; }

    public Guid UserId { get; set; }

    public string OrderStatus { get; set; } = null!;

    public DateTime CreatedAt { get; set; }

    public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
}
