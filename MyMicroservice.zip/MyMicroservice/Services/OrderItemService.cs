﻿using MyMicroservice.Data;
using MyMicroservice.Repositories;

namespace MyMicroservice.Services
{
    public interface IOrderItemService
    {
        List<OrderItem> GetAllOrderItems();
        OrderItem GetOrderItemById(Guid id);
        void AddOrderItem(OrderItem orderItem);
        void DeleteOrderItem(Guid id);
    }
    public class OrderItemService : IOrderItemService
    {
        private readonly IOrderItemRepository _repository;

        public OrderItemService(IOrderItemRepository repository)
        {
            _repository = repository;
        }

        public List<OrderItem> GetAllOrderItems()
        {
            return _repository.GetAllOrderItems();
        }

        public OrderItem GetOrderItemById(Guid id)
        {
            return _repository.GetOrderItemById(id);
        }

        public void AddOrderItem(OrderItem orderItem)
        {
            _repository.AddOrderItem(orderItem);
        }

        public void DeleteOrderItem(Guid id)
        {
            _repository.DeleteOrderItem(id);
        }
    }
}
