﻿using MyMicroservice.Data;
using MyMicroservice.Repositories;

namespace MyMicroservice.Services
{
    public interface IProductService
    {
        List<Product> GetAllProducts();
        Product GetProductById(Guid id);
        void AddOrUpdateProduct(Product product);
        void DeleteProduct(Guid id);
    }
    public class ProductsService : IProductService
    {
        private readonly IProductsRepository _repository;

        public ProductsService(IProductsRepository repository)
        {
            _repository = repository;
        }

        public List<Product> GetAllProducts()
        {
            return _repository.GetAllProducts();
        }

        public Product GetProductById(Guid id)
        {
            return _repository.GetProductById(id);
        }

        public void AddOrUpdateProduct(Product product)
        {
            _repository.AddOrUpdateProduct(product);
        }

        public void DeleteProduct(Guid id)
        {
            _repository.DeleteProduct(id);
        }
    }
}
