﻿using MyMicroservice.Data;
using MyMicroservice.Repositories;

namespace MyMicroservice.Services
{
    public interface IOrderService
    {
        List<Order> GetAllOrders();
        Order GetOrderById(Guid id);
        void AddOrder(Order order);
        void DeleteOrder(Guid id);
    }
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repository;

        public OrderService(IOrderRepository repository)
        {
            _repository = repository;
        }

        public List<Order> GetAllOrders()
        {
            return _repository.GetAllOrders();
        }

        public Order GetOrderById(Guid id)
        {
            return _repository.GetOrderById(id);
        }

        public void AddOrder(Order order)
        {
            _repository.AddOrder(order);
        }

        public void DeleteOrder(Guid id)
        {
            _repository.DeleteOrder(id);
        }
    }
}
