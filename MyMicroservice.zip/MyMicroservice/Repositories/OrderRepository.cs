﻿using Microsoft.EntityFrameworkCore;
using MyMicroservice.Data;

namespace MyMicroservice.Repositories
{
    public interface IOrderRepository
    {
        List<Order> GetAllOrders();
        Order GetOrderById(Guid id);
        void AddOrder(Order order);
        void DeleteOrder(Guid id);
    }
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _context;

        public OrderRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<Order> GetAllOrders()
        {
            return _context.Orders
                .Include(o => o.OrderItems)
                .ToList();
        }

        public Order GetOrderById(Guid id)
        {
            return _context.Orders.Include(o => o.OrderItems).FirstOrDefault(x => x.OrderId == id);
        }

        public void AddOrder(Order order)
        {
            if (order == null)
                return;

            if (order.OrderId == Guid.Empty)
            {
                order.OrderId = Guid.NewGuid();
                order.CreatedAt = DateTime.UtcNow;

                _context.Orders.Add(order);
            }
            else
            {
                var existing = _context.Orders.Include(o => o.OrderItems).FirstOrDefault(x => x.OrderId == order.OrderId);

                if (existing != null)
                {
                    existing.OrderStatus = order.OrderStatus;

                }
            }

            _context.SaveChanges();
        }

        public void DeleteOrder(Guid id)
        {
            var order = _context.Orders.Find(id);

            if (order != null)
            {
                _context.Orders.Remove(order);
                _context.SaveChanges();
            }
        }
    }
}
