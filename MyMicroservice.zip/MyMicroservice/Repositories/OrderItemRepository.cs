﻿using MyMicroservice.Data;

namespace MyMicroservice.Repositories
{
    public interface IOrderItemRepository
    {
        List<OrderItem> GetAllOrderItems();
        OrderItem GetOrderItemById(Guid id);
        void AddOrderItem(OrderItem orderItem);
        void DeleteOrderItem(Guid id);
    }
    public class OrderItemRepository : IOrderItemRepository
    {
        private readonly ApplicationDbContext _context;

        public OrderItemRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public List<OrderItem> GetAllOrderItems()
        {
            return _context.OrderItems.ToList();
        }

        public OrderItem GetOrderItemById(Guid id)
        {
            return _context.OrderItems.FirstOrDefault(x => x.OrderItemId == id);
        }

        public void AddOrderItem(OrderItem orderItem)
        {
            if (orderItem == null)
                return;

            if (orderItem.OrderItemId == Guid.Empty)
            {
                orderItem.OrderItemId = Guid.NewGuid();
                _context.OrderItems.Add(orderItem);
            }
            else
            {
                _context.OrderItems.Update(orderItem);
            }

            _context.SaveChanges();
        }

        public void DeleteOrderItem(Guid id)
        {
            var data = _context.OrderItems.Find(id);

            if (data != null)
            {
                _context.OrderItems.Remove(data);
                _context.SaveChanges();
            }
        }
    }
}
