﻿using MyMicroservice.Data;

namespace MyMicroservice.Repositories
{
    public interface IProductsRepository
    {
        List<Product> GetAllProducts();
        Product GetProductById(Guid id);
        void AddOrUpdateProduct(Product product);
        void DeleteProduct(Guid id);
    }
    public class ProductsRepository : IProductsRepository
    {
        private readonly ApplicationDbContext _context;

        public ProductsRepository(ApplicationDbContext context)
        {
            _context = context;
        }


        public List<Product> GetAllProducts()
        {
            return _context.Products.ToList();
        }

        public Product GetProductById(Guid id)
        {
            return _context.Products.FirstOrDefault(x => x.ProductId == id);
        }

        public void AddOrUpdateProduct(Product product)
        {
            if (product == null)
                return;

            if (product.ProductId == Guid.Empty)
            {
                product.ProductId = Guid.NewGuid();
                product.CreatedAt = DateTime.UtcNow;
                product.IsActive = true;

                _context.Products.Add(product);
            }
            else
            {
                var existing = _context.Products.FirstOrDefault(x => x.ProductId == product.ProductId);

                if (existing != null)
                {
                    existing.ProductName = product.ProductName;
                    existing.StockQty = product.StockQty;
                    existing.IsActive = product.IsActive;

                    existing.UpdatedAt = DateTime.UtcNow;
                }
            }

            _context.SaveChanges();
        }

        public void DeleteProduct(Guid id)
        {
            var product = _context.Products.Find(id);

            if (product != null)
            {
                _context.Products.Remove(product);
                _context.SaveChanges();
            }
        }
    }
}
