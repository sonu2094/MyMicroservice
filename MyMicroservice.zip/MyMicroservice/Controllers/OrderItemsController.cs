﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MyMicroservice.Data;
using MyMicroservice.Services;

namespace MyMicroservice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemsController : ControllerBase
    {
        private readonly IOrderItemService _service;

        public OrderItemsController(IOrderItemService service)
        {
            _service = service;
        }

        // GET: api/orderitems
        [HttpGet]
        public ActionResult<List<OrderItem>> GetAll()
        {
            return Ok(_service.GetAllOrderItems());
        }

        // GET: api/orderitems/{id}
        [HttpGet("{id}")]
        public ActionResult<OrderItem> GetById(Guid id)
        {
            var item = _service.GetOrderItemById(id);

            if (item == null)
                return NotFound();

            return Ok(item);
        }

        // POST: api/orderitems
        [HttpPost]
        public ActionResult Add(OrderItem orderItem)
        {
            _service.AddOrderItem(orderItem);
            return Ok("Order item saved successfully");
        }

        // DELETE: api/orderitems/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(Guid id)
        {
            _service.DeleteOrderItem(id);
            return Ok("Order item deleted successfully");
        }
    }
}
