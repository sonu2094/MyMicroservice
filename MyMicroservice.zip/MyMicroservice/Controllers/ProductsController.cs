﻿using Microsoft.AspNetCore.Mvc;
using MyMicroservice.Data;
using MyMicroservice.Services;

namespace MyMicroservice.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductsController(IProductService service)
        {
            _service = service;
        }

        // GET: api/products
        [HttpGet]
        public ActionResult<List<Product>> GetAll()
        {
            return Ok(_service.GetAllProducts());
        }

        // GET: api/products/{id}
        [HttpGet("{id}")]
        public ActionResult<Product> GetById(Guid id)
        {
            var product = _service.GetProductById(id);

            if (product == null)
                return NotFound();

            return Ok(product);
        }

        // POST: api/products
        [HttpPost]
        public ActionResult Add(Product product)
        {
            _service.AddOrUpdateProduct(product);
            return Ok("Product saved successfully");
        }

        // DELETE: api/products/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(Guid id)
        {
            _service.DeleteProduct(id);
            return Ok("Product deleted successfully");
        }
    }
}
