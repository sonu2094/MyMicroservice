﻿using Microsoft.AspNetCore.Mvc;
using MyMicroservice.Data;
using MyMicroservice.Services;

namespace MyMicroservice.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _service;

        public OrdersController(IOrderService service)
        {
            _service = service;
        }

        // GET: api/orders
        [HttpGet]
        public ActionResult<List<Order>> GetAll()
        {
            return Ok(_service.GetAllOrders());
        }

        // GET: api/orders/{id}
        [HttpGet("{id}")]
        public ActionResult<Order> GetById(Guid id)
        {
            var order = _service.GetOrderById(id);

            if (order == null)
                return NotFound();

            return Ok(order);
        }

        // POST: api/orders
        [HttpPost]
        public ActionResult Add(Order order)
        {
            _service.AddOrder(order);
            return Ok("Order saved successfully");
        }

        // DELETE: api/orders/{id}
        [HttpDelete("{id}")]
        public ActionResult Delete(Guid id)
        {
            _service.DeleteOrder(id);
            return Ok("Order deleted successfully");
        }
    }
}
